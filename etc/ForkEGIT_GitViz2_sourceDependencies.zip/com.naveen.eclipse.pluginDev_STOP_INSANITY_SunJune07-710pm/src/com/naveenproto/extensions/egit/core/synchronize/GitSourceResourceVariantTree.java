/*******************************************************************************
 * Copyright (c) 2013 Obeo.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     Laurent Goubet <laurent.goubet@obeo.fr> - initial API and implementation
 *******************************************************************************/
package com.davidproto.extensions.egit.core.synchronize;
//package org.eclipse.egit.core.synchronize;

import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.team.core.variants.ResourceVariantByteStore;

class GitSourceResourceVariantTree extends GitResourceVariantTree {

	GitSourceResourceVariantTree(
			ResourceVariantByteStore store,
			GitSyncCache gitCache,
			com.davidproto.extensions.egit.core.synchronize.dto.GitSynchronizeDataSet gsds) {
		super(store, gitCache, gsds);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected ObjectId getObjectId(ThreeWayDiffEntry diffEntry) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected RevCommit getCommitId(
			com.davidproto.extensions.egit.core.synchronize.dto.GitSynchronizeData gsd) {
		// TODO Auto-generated method stub
		return null;
	}
//TODO
	}