package com.davidproto.extensions.eclipse.jface;

import java.util.List;

import org.eclipse.jface.viewers.StructuredViewer;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Widget;

public class GitVizJFaceStructuredViewer { //extends StructuredViewer {
												// Abstract - TODO: find the EGIT concrete class, at runtime ????
	
	/**	
	@Override
	protected Widget doFindInputItem(Object element) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Widget doFindItem(Object element) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void doUpdateItem(Widget item, Object element, boolean fullMap) {
		// TODO Auto-generated method stub

	}

	@Override
	protected List getSelectionFromWidget() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void internalRefresh(Object element) {
		// TODO Auto-generated method stub

	}

	@Override
	public void reveal(Object element) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void setSelectionToWidget(List l, boolean reveal) {
		// TODO Auto-generated method stub

	}

@Override
public Control getControl() {
	System.out.println("~~GVA: VIEW JFACE : getControl() @ GitVizJFaceStructuredViewer ");
	return super.getControl();
}
**/
	
	
}
