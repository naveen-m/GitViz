package com.davidproto.extensions.egit;

import org.eclipse.egit.ui.IBranchNameProvider;

public class FancyGitVizView implements IBranchNameProvider {
							//TODO: find concrete class to extend .... GITVIZ plugin.xml
	
	public String getBranchNameSuggestion() {

		System.out.println("~~GVA: FancyGitVizView.getBranchNameSuggestion() - from Interface ");
		
		// TODO Auto-generated method stub
		return null;
	}

}
