package com.davidproto.extensions.eclipse;

import org.eclipse.jface.viewers.ISelection;
import org.eclipse.ui.part.ShowInContext;

public class GitVizEclipseExtendedShowInContext extends ShowInContext {
	// Okay: concrete Class extension !!!

	public GitVizEclipseExtendedShowInContext(Object input, ISelection selection) {
		super(input, selection);

		System.out.println("~~GVA: created new instance for Extended Class, GitVizEclipseExtendedShowInContext");
	}

}
