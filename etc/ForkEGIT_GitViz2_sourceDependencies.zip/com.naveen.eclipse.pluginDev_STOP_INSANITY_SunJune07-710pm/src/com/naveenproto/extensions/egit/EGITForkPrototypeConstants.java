package com.davidproto.extensions.egit;

public class EGITForkPrototypeConstants {

	/**
	 * @return the name of this plugin
	 */
	public static String getPluginId() {
		//return org.eclipse.egit.core.Activator.getPluginId()
		return com.drobesh.eclipse.plugindev.Activator.getPluginId();
	}

}
