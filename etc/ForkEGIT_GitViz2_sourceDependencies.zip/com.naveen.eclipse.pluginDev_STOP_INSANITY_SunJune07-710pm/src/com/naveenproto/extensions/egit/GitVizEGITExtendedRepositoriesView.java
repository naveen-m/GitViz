package com.davidproto.extensions.egit;

import org.eclipse.egit.ui.internal.repository.RepositoriesView;

@SuppressWarnings("restriction")
public class GitVizEGITExtendedRepositoriesView { // extends RepositoriesView {

}
